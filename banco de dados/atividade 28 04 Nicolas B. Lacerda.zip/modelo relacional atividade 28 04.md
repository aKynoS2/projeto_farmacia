**Estrada**

id\_estrada (PK)

nome

velocidade\_max

id\_categoria (FK)

id\_classificacao (FK)



**Categoria**

id\_categoria (PK)

descricao



**Classificacao**

id\_classificacao (PK)

descricao



**Cidade**

id\_cidade (PK)

nome



**Trecho**

id\_trecho (PK)

id\_estrada (FK)

km\_inicio

km\_fim

velocidade\_limite

id\_condicao (FK)



**Condicao**

id\_condicao (PK)

descricao



**Ocorrencia**

id\_ocorrencia (PK)

id\_trecho (FK)

tipo

descricao

data\_inicio

data\_fim

